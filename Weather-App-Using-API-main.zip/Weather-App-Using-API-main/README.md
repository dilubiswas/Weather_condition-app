# Weather App Using API

Weather App Using API

# Output
![p1](https://user-images.githubusercontent.com/109650374/207336671-14a72525-8e23-4823-8c18-4e2eb4a21b47.jpeg)
